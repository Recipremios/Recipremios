import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCs923d6-WZ7kEXoaJrRaoMm-7NvDjb_sg",
            authDomain: "recipremios-869fuw.firebaseapp.com",
            projectId: "recipremios-869fuw",
            storageBucket: "recipremios-869fuw.appspot.com",
            messagingSenderId: "697810900248",
            appId: "1:697810900248:web:32f5f538a89ad93e15fa6d"));
  } else {
    await Firebase.initializeApp();
  }
}
