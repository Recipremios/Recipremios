import 'package:collection/collection.dart';

enum TamanoDispositivo {
  pequeno,
  mediano,
  grande,
  enorme,
}

enum HorarioRecoleccion {
  AM,
  PM,
}

enum EstadoRecoleccion {
  pendiente,
  completada,
  cancelada,
}

enum TipoPremio {
  tangible,
  intangible,
}

enum EstadoCanje {
  pendiente,
  enviado,
  entregado,
}

extension FFEnumExtensions<T extends Enum> on T {
  String serialize() => name;
}

extension FFEnumListExtensions<T extends Enum> on Iterable<T> {
  T? deserialize(String? value) =>
      firstWhereOrNull((e) => e.serialize() == value);
}

T? deserializeEnum<T>(String? value) {
  switch (T) {
    case (TamanoDispositivo):
      return TamanoDispositivo.values.deserialize(value) as T?;
    case (HorarioRecoleccion):
      return HorarioRecoleccion.values.deserialize(value) as T?;
    case (EstadoRecoleccion):
      return EstadoRecoleccion.values.deserialize(value) as T?;
    case (TipoPremio):
      return TipoPremio.values.deserialize(value) as T?;
    case (EstadoCanje):
      return EstadoCanje.values.deserialize(value) as T?;
    default:
      return null;
  }
}
