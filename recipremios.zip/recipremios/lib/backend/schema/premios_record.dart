import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PremiosRecord extends FirestoreRecord {
  PremiosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "nombre" field.
  String? _nombre;
  String get nombre => _nombre ?? '';
  bool hasNombre() => _nombre != null;

  // "descripcion" field.
  String? _descripcion;
  String get descripcion => _descripcion ?? '';
  bool hasDescripcion() => _descripcion != null;

  // "tipoPremio" field.
  TipoPremio? _tipoPremio;
  TipoPremio? get tipoPremio => _tipoPremio;
  bool hasTipoPremio() => _tipoPremio != null;

  // "valor" field.
  double? _valor;
  double get valor => _valor ?? 0.0;
  bool hasValor() => _valor != null;

  // "imagenURL" field.
  String? _imagenURL;
  String get imagenURL => _imagenURL ?? '';
  bool hasImagenURL() => _imagenURL != null;

  void _initializeFields() {
    _nombre = snapshotData['nombre'] as String?;
    _descripcion = snapshotData['descripcion'] as String?;
    _tipoPremio = deserializeEnum<TipoPremio>(snapshotData['tipoPremio']);
    _valor = castToType<double>(snapshotData['valor']);
    _imagenURL = snapshotData['imagenURL'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Premios');

  static Stream<PremiosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PremiosRecord.fromSnapshot(s));

  static Future<PremiosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PremiosRecord.fromSnapshot(s));

  static PremiosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PremiosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PremiosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PremiosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PremiosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PremiosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPremiosRecordData({
  String? nombre,
  String? descripcion,
  TipoPremio? tipoPremio,
  double? valor,
  String? imagenURL,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nombre': nombre,
      'descripcion': descripcion,
      'tipoPremio': tipoPremio,
      'valor': valor,
      'imagenURL': imagenURL,
    }.withoutNulls,
  );

  return firestoreData;
}

class PremiosRecordDocumentEquality implements Equality<PremiosRecord> {
  const PremiosRecordDocumentEquality();

  @override
  bool equals(PremiosRecord? e1, PremiosRecord? e2) {
    return e1?.nombre == e2?.nombre &&
        e1?.descripcion == e2?.descripcion &&
        e1?.tipoPremio == e2?.tipoPremio &&
        e1?.valor == e2?.valor &&
        e1?.imagenURL == e2?.imagenURL;
  }

  @override
  int hash(PremiosRecord? e) => const ListEquality()
      .hash([e?.nombre, e?.descripcion, e?.tipoPremio, e?.valor, e?.imagenURL]);

  @override
  bool isValidKey(Object? o) => o is PremiosRecord;
}
