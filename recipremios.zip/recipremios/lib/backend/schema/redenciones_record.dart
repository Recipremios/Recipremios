import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RedencionesRecord extends FirestoreRecord {
  RedencionesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "UserID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "PremioID" field.
  DocumentReference? _premioID;
  DocumentReference? get premioID => _premioID;
  bool hasPremioID() => _premioID != null;

  // "FechaCanje" field.
  DateTime? _fechaCanje;
  DateTime? get fechaCanje => _fechaCanje;
  bool hasFechaCanje() => _fechaCanje != null;

  // "EstadoCanje" field.
  EstadoCanje? _estadoCanje;
  EstadoCanje? get estadoCanje => _estadoCanje;
  bool hasEstadoCanje() => _estadoCanje != null;

  void _initializeFields() {
    _userID = snapshotData['UserID'] as DocumentReference?;
    _premioID = snapshotData['PremioID'] as DocumentReference?;
    _fechaCanje = snapshotData['FechaCanje'] as DateTime?;
    _estadoCanje = deserializeEnum<EstadoCanje>(snapshotData['EstadoCanje']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Redenciones');

  static Stream<RedencionesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RedencionesRecord.fromSnapshot(s));

  static Future<RedencionesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RedencionesRecord.fromSnapshot(s));

  static RedencionesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RedencionesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RedencionesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RedencionesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RedencionesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RedencionesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRedencionesRecordData({
  DocumentReference? userID,
  DocumentReference? premioID,
  DateTime? fechaCanje,
  EstadoCanje? estadoCanje,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'UserID': userID,
      'PremioID': premioID,
      'FechaCanje': fechaCanje,
      'EstadoCanje': estadoCanje,
    }.withoutNulls,
  );

  return firestoreData;
}

class RedencionesRecordDocumentEquality implements Equality<RedencionesRecord> {
  const RedencionesRecordDocumentEquality();

  @override
  bool equals(RedencionesRecord? e1, RedencionesRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.premioID == e2?.premioID &&
        e1?.fechaCanje == e2?.fechaCanje &&
        e1?.estadoCanje == e2?.estadoCanje;
  }

  @override
  int hash(RedencionesRecord? e) => const ListEquality()
      .hash([e?.userID, e?.premioID, e?.fechaCanje, e?.estadoCanje]);

  @override
  bool isValidKey(Object? o) => o is RedencionesRecord;
}
