import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DispositivosRecord extends FirestoreRecord {
  DispositivosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Tamano" field.
  TamanoDispositivo? _tamano;
  TamanoDispositivo? get tamano => _tamano;
  bool hasTamano() => _tamano != null;

  // "UserID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "Marca" field.
  String? _marca;
  String get marca => _marca ?? '';
  bool hasMarca() => _marca != null;

  // "Modelo" field.
  String? _modelo;
  String get modelo => _modelo ?? '';
  bool hasModelo() => _modelo != null;

  void _initializeFields() {
    _tamano = deserializeEnum<TamanoDispositivo>(snapshotData['Tamano']);
    _userID = snapshotData['UserID'] as DocumentReference?;
    _marca = snapshotData['Marca'] as String?;
    _modelo = snapshotData['Modelo'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Dispositivos');

  static Stream<DispositivosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DispositivosRecord.fromSnapshot(s));

  static Future<DispositivosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DispositivosRecord.fromSnapshot(s));

  static DispositivosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DispositivosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DispositivosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DispositivosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DispositivosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DispositivosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDispositivosRecordData({
  TamanoDispositivo? tamano,
  DocumentReference? userID,
  String? marca,
  String? modelo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Tamano': tamano,
      'UserID': userID,
      'Marca': marca,
      'Modelo': modelo,
    }.withoutNulls,
  );

  return firestoreData;
}

class DispositivosRecordDocumentEquality
    implements Equality<DispositivosRecord> {
  const DispositivosRecordDocumentEquality();

  @override
  bool equals(DispositivosRecord? e1, DispositivosRecord? e2) {
    return e1?.tamano == e2?.tamano &&
        e1?.userID == e2?.userID &&
        e1?.marca == e2?.marca &&
        e1?.modelo == e2?.modelo;
  }

  @override
  int hash(DispositivosRecord? e) =>
      const ListEquality().hash([e?.tamano, e?.userID, e?.marca, e?.modelo]);

  @override
  bool isValidKey(Object? o) => o is DispositivosRecord;
}
