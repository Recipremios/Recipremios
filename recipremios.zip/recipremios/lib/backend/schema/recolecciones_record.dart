import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RecoleccionesRecord extends FirestoreRecord {
  RecoleccionesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "UserID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "Barrio" field.
  String? _barrio;
  String get barrio => _barrio ?? '';
  bool hasBarrio() => _barrio != null;

  // "FechaRecoleccion" field.
  DateTime? _fechaRecoleccion;
  DateTime? get fechaRecoleccion => _fechaRecoleccion;
  bool hasFechaRecoleccion() => _fechaRecoleccion != null;

  // "HorarioRecoleccion" field.
  HorarioRecoleccion? _horarioRecoleccion;
  HorarioRecoleccion? get horarioRecoleccion => _horarioRecoleccion;
  bool hasHorarioRecoleccion() => _horarioRecoleccion != null;

  // "EstadoRecoleccion" field.
  EstadoRecoleccion? _estadoRecoleccion;
  EstadoRecoleccion? get estadoRecoleccion => _estadoRecoleccion;
  bool hasEstadoRecoleccion() => _estadoRecoleccion != null;

  // "DireccionRecoleccion" field.
  String? _direccionRecoleccion;
  String get direccionRecoleccion => _direccionRecoleccion ?? '';
  bool hasDireccionRecoleccion() => _direccionRecoleccion != null;

  // "DispositivoID" field.
  DocumentReference? _dispositivoID;
  DocumentReference? get dispositivoID => _dispositivoID;
  bool hasDispositivoID() => _dispositivoID != null;

  void _initializeFields() {
    _userID = snapshotData['UserID'] as DocumentReference?;
    _barrio = snapshotData['Barrio'] as String?;
    _fechaRecoleccion = snapshotData['FechaRecoleccion'] as DateTime?;
    _horarioRecoleccion =
        deserializeEnum<HorarioRecoleccion>(snapshotData['HorarioRecoleccion']);
    _estadoRecoleccion =
        deserializeEnum<EstadoRecoleccion>(snapshotData['EstadoRecoleccion']);
    _direccionRecoleccion = snapshotData['DireccionRecoleccion'] as String?;
    _dispositivoID = snapshotData['DispositivoID'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Recolecciones');

  static Stream<RecoleccionesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RecoleccionesRecord.fromSnapshot(s));

  static Future<RecoleccionesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RecoleccionesRecord.fromSnapshot(s));

  static RecoleccionesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RecoleccionesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RecoleccionesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RecoleccionesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RecoleccionesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RecoleccionesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRecoleccionesRecordData({
  DocumentReference? userID,
  String? barrio,
  DateTime? fechaRecoleccion,
  HorarioRecoleccion? horarioRecoleccion,
  EstadoRecoleccion? estadoRecoleccion,
  String? direccionRecoleccion,
  DocumentReference? dispositivoID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'UserID': userID,
      'Barrio': barrio,
      'FechaRecoleccion': fechaRecoleccion,
      'HorarioRecoleccion': horarioRecoleccion,
      'EstadoRecoleccion': estadoRecoleccion,
      'DireccionRecoleccion': direccionRecoleccion,
      'DispositivoID': dispositivoID,
    }.withoutNulls,
  );

  return firestoreData;
}

class RecoleccionesRecordDocumentEquality
    implements Equality<RecoleccionesRecord> {
  const RecoleccionesRecordDocumentEquality();

  @override
  bool equals(RecoleccionesRecord? e1, RecoleccionesRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.barrio == e2?.barrio &&
        e1?.fechaRecoleccion == e2?.fechaRecoleccion &&
        e1?.horarioRecoleccion == e2?.horarioRecoleccion &&
        e1?.estadoRecoleccion == e2?.estadoRecoleccion &&
        e1?.direccionRecoleccion == e2?.direccionRecoleccion &&
        e1?.dispositivoID == e2?.dispositivoID;
  }

  @override
  int hash(RecoleccionesRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.barrio,
        e?.fechaRecoleccion,
        e?.horarioRecoleccion,
        e?.estadoRecoleccion,
        e?.direccionRecoleccion,
        e?.dispositivoID
      ]);

  @override
  bool isValidKey(Object? o) => o is RecoleccionesRecord;
}
