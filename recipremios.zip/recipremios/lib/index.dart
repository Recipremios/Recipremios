// Export pages
export '/login/login_widget.dart' show LoginWidget;
export '/register/register_widget.dart' show RegisterWidget;
export '/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/address/address_widget.dart' show AddressWidget;
export '/fecha_recoleccion/fecha_recoleccion_widget.dart'
    show FechaRecoleccionWidget;
export '/gracias/gracias_widget.dart' show GraciasWidget;
