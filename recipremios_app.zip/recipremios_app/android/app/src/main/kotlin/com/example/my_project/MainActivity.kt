package com.mycompany.recipremiosapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
