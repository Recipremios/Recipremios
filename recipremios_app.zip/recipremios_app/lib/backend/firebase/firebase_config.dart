import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDeQaEYXcHwziAg1x8iDyAqOcs5oFadX2A",
            authDomain: "recipremios-app-dqdpdf.firebaseapp.com",
            projectId: "recipremios-app-dqdpdf",
            storageBucket: "recipremios-app-dqdpdf.appspot.com",
            messagingSenderId: "385241401083",
            appId: "1:385241401083:web:076693dd4cd364a4eb925e"));
  } else {
    await Firebase.initializeApp();
  }
}
