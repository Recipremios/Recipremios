import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DispositivosRecord extends FirestoreRecord {
  DispositivosRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "tamanoDispositivo" field.
  TamanoDispositivo? _tamanoDispositivo;
  TamanoDispositivo? get tamanoDispositivo => _tamanoDispositivo;
  bool hasTamanoDispositivo() => _tamanoDispositivo != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "nombreUsuario" field.
  String? _nombreUsuario;
  String get nombreUsuario => _nombreUsuario ?? '';
  bool hasNombreUsuario() => _nombreUsuario != null;

  // "telefonoUsuario" field.
  String? _telefonoUsuario;
  String get telefonoUsuario => _telefonoUsuario ?? '';
  bool hasTelefonoUsuario() => _telefonoUsuario != null;

  // "marcaDispositivo" field.
  String? _marcaDispositivo;
  String get marcaDispositivo => _marcaDispositivo ?? '';
  bool hasMarcaDispositivo() => _marcaDispositivo != null;

  // "direccionUsuario" field.
  String? _direccionUsuario;
  String get direccionUsuario => _direccionUsuario ?? '';
  bool hasDireccionUsuario() => _direccionUsuario != null;

  // "barrioUsuario" field.
  String? _barrioUsuario;
  String get barrioUsuario => _barrioUsuario ?? '';
  bool hasBarrioUsuario() => _barrioUsuario != null;

  // "photoDispositivo" field.
  String? _photoDispositivo;
  String get photoDispositivo => _photoDispositivo ?? '';
  bool hasPhotoDispositivo() => _photoDispositivo != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _tamanoDispositivo =
        deserializeEnum<TamanoDispositivo>(snapshotData['tamanoDispositivo']);
    _createdTime = snapshotData['createdTime'] as DateTime?;
    _nombreUsuario = snapshotData['nombreUsuario'] as String?;
    _telefonoUsuario = snapshotData['telefonoUsuario'] as String?;
    _marcaDispositivo = snapshotData['marcaDispositivo'] as String?;
    _direccionUsuario = snapshotData['direccionUsuario'] as String?;
    _barrioUsuario = snapshotData['barrioUsuario'] as String?;
    _photoDispositivo = snapshotData['photoDispositivo'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('dispositivos');

  static Stream<DispositivosRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DispositivosRecord.fromSnapshot(s));

  static Future<DispositivosRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DispositivosRecord.fromSnapshot(s));

  static DispositivosRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DispositivosRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DispositivosRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DispositivosRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DispositivosRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DispositivosRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDispositivosRecordData({
  DocumentReference? userID,
  TamanoDispositivo? tamanoDispositivo,
  DateTime? createdTime,
  String? nombreUsuario,
  String? telefonoUsuario,
  String? marcaDispositivo,
  String? direccionUsuario,
  String? barrioUsuario,
  String? photoDispositivo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'tamanoDispositivo': tamanoDispositivo,
      'createdTime': createdTime,
      'nombreUsuario': nombreUsuario,
      'telefonoUsuario': telefonoUsuario,
      'marcaDispositivo': marcaDispositivo,
      'direccionUsuario': direccionUsuario,
      'barrioUsuario': barrioUsuario,
      'photoDispositivo': photoDispositivo,
    }.withoutNulls,
  );

  return firestoreData;
}

class DispositivosRecordDocumentEquality
    implements Equality<DispositivosRecord> {
  const DispositivosRecordDocumentEquality();

  @override
  bool equals(DispositivosRecord? e1, DispositivosRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.tamanoDispositivo == e2?.tamanoDispositivo &&
        e1?.createdTime == e2?.createdTime &&
        e1?.nombreUsuario == e2?.nombreUsuario &&
        e1?.telefonoUsuario == e2?.telefonoUsuario &&
        e1?.marcaDispositivo == e2?.marcaDispositivo &&
        e1?.direccionUsuario == e2?.direccionUsuario &&
        e1?.barrioUsuario == e2?.barrioUsuario &&
        e1?.photoDispositivo == e2?.photoDispositivo;
  }

  @override
  int hash(DispositivosRecord? e) => const ListEquality().hash([
        e?.userID,
        e?.tamanoDispositivo,
        e?.createdTime,
        e?.nombreUsuario,
        e?.telefonoUsuario,
        e?.marcaDispositivo,
        e?.direccionUsuario,
        e?.barrioUsuario,
        e?.photoDispositivo
      ]);

  @override
  bool isValidKey(Object? o) => o is DispositivosRecord;
}
