import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';
import '/backend/schema/enums/enums.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RedencionesRecord extends FirestoreRecord {
  RedencionesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userID" field.
  DocumentReference? _userID;
  DocumentReference? get userID => _userID;
  bool hasUserID() => _userID != null;

  // "premioID" field.
  DocumentReference? _premioID;
  DocumentReference? get premioID => _premioID;
  bool hasPremioID() => _premioID != null;

  // "fechaCanje" field.
  DateTime? _fechaCanje;
  DateTime? get fechaCanje => _fechaCanje;
  bool hasFechaCanje() => _fechaCanje != null;

  // "estadoCanje" field.
  EstadoRecoleccion? _estadoCanje;
  EstadoRecoleccion? get estadoCanje => _estadoCanje;
  bool hasEstadoCanje() => _estadoCanje != null;

  void _initializeFields() {
    _userID = snapshotData['userID'] as DocumentReference?;
    _premioID = snapshotData['premioID'] as DocumentReference?;
    _fechaCanje = snapshotData['fechaCanje'] as DateTime?;
    _estadoCanje =
        deserializeEnum<EstadoRecoleccion>(snapshotData['estadoCanje']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('redenciones');

  static Stream<RedencionesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RedencionesRecord.fromSnapshot(s));

  static Future<RedencionesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RedencionesRecord.fromSnapshot(s));

  static RedencionesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RedencionesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RedencionesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RedencionesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RedencionesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RedencionesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRedencionesRecordData({
  DocumentReference? userID,
  DocumentReference? premioID,
  DateTime? fechaCanje,
  EstadoRecoleccion? estadoCanje,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userID': userID,
      'premioID': premioID,
      'fechaCanje': fechaCanje,
      'estadoCanje': estadoCanje,
    }.withoutNulls,
  );

  return firestoreData;
}

class RedencionesRecordDocumentEquality implements Equality<RedencionesRecord> {
  const RedencionesRecordDocumentEquality();

  @override
  bool equals(RedencionesRecord? e1, RedencionesRecord? e2) {
    return e1?.userID == e2?.userID &&
        e1?.premioID == e2?.premioID &&
        e1?.fechaCanje == e2?.fechaCanje &&
        e1?.estadoCanje == e2?.estadoCanje;
  }

  @override
  int hash(RedencionesRecord? e) => const ListEquality()
      .hash([e?.userID, e?.premioID, e?.fechaCanje, e?.estadoCanje]);

  @override
  bool isValidKey(Object? o) => o is RedencionesRecord;
}
