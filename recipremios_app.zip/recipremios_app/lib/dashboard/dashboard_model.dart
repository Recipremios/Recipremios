import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dashboard_widget.dart' show DashboardWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DashboardModel extends FlutterFlowModel<DashboardWidget> {
  ///  Local state fields for this page.

  String? miimagentemporal;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for nombreUsuario widget.
  FocusNode? nombreUsuarioFocusNode;
  TextEditingController? nombreUsuarioTextController;
  String? Function(BuildContext, String?)? nombreUsuarioTextControllerValidator;
  // State field(s) for telefonoUsuario widget.
  FocusNode? telefonoUsuarioFocusNode;
  TextEditingController? telefonoUsuarioTextController;
  String? Function(BuildContext, String?)?
      telefonoUsuarioTextControllerValidator;
  // State field(s) for direccionUsuario widget.
  FocusNode? direccionUsuarioFocusNode;
  TextEditingController? direccionUsuarioTextController;
  String? Function(BuildContext, String?)?
      direccionUsuarioTextControllerValidator;
  // State field(s) for barrioUsuario widget.
  FocusNode? barrioUsuarioFocusNode;
  TextEditingController? barrioUsuarioTextController;
  String? Function(BuildContext, String?)? barrioUsuarioTextControllerValidator;
  // State field(s) for marcaDispositivo widget.
  FocusNode? marcaDispositivoFocusNode;
  TextEditingController? marcaDispositivoTextController;
  String? Function(BuildContext, String?)?
      marcaDispositivoTextControllerValidator;
  bool isDataUploading1 = false;
  FFUploadedFile uploadedLocalFile1 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl1 = '';

  bool isDataUploading2 = false;
  FFUploadedFile uploadedLocalFile2 =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl2 = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    nombreUsuarioFocusNode?.dispose();
    nombreUsuarioTextController?.dispose();

    telefonoUsuarioFocusNode?.dispose();
    telefonoUsuarioTextController?.dispose();

    direccionUsuarioFocusNode?.dispose();
    direccionUsuarioTextController?.dispose();

    barrioUsuarioFocusNode?.dispose();
    barrioUsuarioTextController?.dispose();

    marcaDispositivoFocusNode?.dispose();
    marcaDispositivoTextController?.dispose();
  }
}
