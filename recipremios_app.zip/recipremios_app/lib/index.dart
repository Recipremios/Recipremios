// Export pages
export '/registro/registro_widget.dart' show RegistroWidget;
export '/direccion/direccion_widget.dart' show DireccionWidget;
export '/fecha_recoleccion/fecha_recoleccion_widget.dart'
    show FechaRecoleccionWidget;
export '/gracias/gracias_widget.dart' show GraciasWidget;
export '/dashboard/dashboard_widget.dart' show DashboardWidget;
